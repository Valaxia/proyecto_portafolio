<?php 

/*
Template Name: Servicios
*/


 ?>

 <h1>hola desde servicios</h1>