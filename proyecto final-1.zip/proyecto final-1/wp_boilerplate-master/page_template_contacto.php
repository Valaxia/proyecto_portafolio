<?php 

/*
Template Name: Comtacto
*/


 ?>

 <h1>hola desde contacto</h1>