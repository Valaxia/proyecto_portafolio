<?php get_header() ?>

Hola desde index


		
<?php get_footer() ?>